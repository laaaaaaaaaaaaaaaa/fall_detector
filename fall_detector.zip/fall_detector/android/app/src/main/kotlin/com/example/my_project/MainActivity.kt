package com.mycompany.TAlala

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
